AOS.init();

// let Navbar = document.querySelector("#navbar");

// window.addEventListener("scroll", function () {
//   let scroll = window.scrollY; // Fixing incorrect reference
//   if (scroll > 400) {
//     // Adjust scroll threshold
//     Navbar.classList.add("sticky");
//   } else {
//     Navbar.classList.remove("sticky");
//   }
// });

document.addEventListener("DOMContentLoaded", function () {
  const images = document.querySelectorAll(".demos-container img"); // Select all images

  images.forEach((img) => {
    img.addEventListener("mouseenter", function () {
      img.style.transition = "transform 3s linear";
      img.style.transform = "translateY(-60%)";
    });

    img.addEventListener("mouseleave", function () {
      img.style.transition = "transform 3s linear";
      img.style.transform = "translateY(0)";
    });
  });
});
